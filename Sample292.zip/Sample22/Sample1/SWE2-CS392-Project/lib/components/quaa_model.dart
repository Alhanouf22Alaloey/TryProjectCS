import '/flutter_flow/flutter_flow_util.dart';
import 'quaa_widget.dart' show QuaaWidget;
import 'package:flutter/material.dart';

class QuaaModel extends FlutterFlowModel<QuaaWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Checkbox widget.
  bool? checkboxValue;

  /// Initialization and disposal methods.

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
